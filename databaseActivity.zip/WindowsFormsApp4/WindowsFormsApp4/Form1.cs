﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\TestDB.mdf;Integrated Security=True;Connect Timeout=30");
            string qry = "insert into Login values(1, 'Admin')";
            SqlCommand cmd = new SqlCommand(qry,con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data Inseerted Successfully");
            }
            catch(SqlException ex)
            {
                MessageBox.Show("" + ex);
            }
        }
    }
}
