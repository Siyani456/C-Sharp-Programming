﻿using System;

namespace ConsoleApp8
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                double tot = Double.Parse("0123 -89");
            }
            
           catch(Exception ex)
            {
                Console.WriteLine("Bug has detected");
                Console.WriteLine("ex");
            }
            finally
            {
                Console.WriteLine("press any key to continue");
            }
            Console.ReadLine();
        }
    }
}
